📈 Stock Market Portfolio Optimizer

# 🌱 ESG Portfolio Optimizer (Streamlit App)

This is a web app that lets you build an optimal portfolio of stocks based on ESG (Environmental, Social, Governance) scores and modern portfolio theory using PyPortfolioOpt.

---

## 🚀 Features

- ESG Score Filtering (via Finnhub API)
- Portfolio optimization using Sharpe Ratio
- Allocation pie chart
- Historical stock price chart
- Portfolio metrics: Return, Risk, Sharpe Ratio
- Correlation heatmap (Risk Analysis)
- Value at Risk (VaR) and Conditional VaR (CVaR)
- Light/Dark mode toggle (Custom Theme)

---

## 🛠️ Installation

```bash
# 1. Create a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

#3.how to run?
streamlit run app.py

#4.ESG API key
The app uses ESG scores via Finnhub API. Get your free API key and update it in optimizer.py
FINNHUB_API_KEY = "your_key_here"

👩‍💻 Built by
Srushti (Engineer | 2026 Graduate)
