# app.py
import streamlit as st
import pandas as pd
import plotly.express as px
import numpy as np
from optimizer import get_data, optimize_portfolio, calculate_correlation_heatmap

# Streamlit page config
st.set_page_config(page_title="🌱 ESG Portfolio Optimizer", layout="centered")

# Dark/Light Theme Toggle
dark_mode = st.sidebar.toggle("🌙 Dark Mode", value=False)

# Custom CSS for Dark/Light Theme
if dark_mode:
    st.markdown("""
    <style>
        body, .main, .block-container {
            background-color: #0e1117;
            color: #ffffff;
        }
        .stButton > button {
            background-color: #90ee90;
            color: #000000;
            border-radius: 8px;
        }
    </style>
    """, unsafe_allow_html=True)
else:
    st.markdown("""
    <style>
        body, .main, .block-container {
            background-color: #f5f5f5;
            color: #000000;
        }
        .stButton > button {
            background-color: #4CAF50;
            color: white;
            border-radius: 8px;
        }
    </style>
    """, unsafe_allow_html=True)

# Title
st.title("📈 Stock Market Portfolio Optimizer")

# Inputs
tickers_input = st.text_input("Enter stock tickers (comma-separated):", "AAPL, MSFT, GOOGL, AMZN")
tickers = [t.strip().upper() for t in tickers_input.split(",") if t.strip()]
use_esg = st.checkbox("Enable ESG Filtering")
min_score = st.slider("Minimum ESG Score", 0, 100, 70) if use_esg else 0

# Optimize button
if st.button("🚀 Optimize Portfolio"):
    if not tickers:
        st.warning("⚠️ Please enter at least one valid ticker.")
    else:
        try:
            data, esg_scores = get_data(tickers, use_esg, min_score)
            if data.empty:
                st.error("❌ No data after ESG filtering. Try valid tickers or lower ESG threshold.")
            else:
                weights, exp_return, risk, sharpe = optimize_portfolio(data)

                st.success("✅ Portfolio Optimization Complete")

                # Pie chart
                st.subheader("📊 Portfolio Allocation")
                pie_data = pd.DataFrame({
                    "Ticker": list(weights.keys()),
                    "Weight (%)": [w * 100 for w in weights.values()]
                })
                fig = px.pie(pie_data, names="Ticker", values="Weight (%)",
                             title="Portfolio Allocation", hole=0.3)
                st.plotly_chart(fig, use_container_width=True)

                # Line chart
                st.subheader("📈 Historical Price Trend")
                st.line_chart(data)

                # Portfolio metrics
                st.subheader("📋 Portfolio Metrics")
                st.metric("Expected Annual Return", f"{exp_return * 100:.2f}%")
                st.metric("Volatility (Risk)", f"{risk * 100:.2f}%")
                st.metric("Sharpe Ratio", f"{sharpe:.2f}")

                # ESG Scores
                if use_esg:
                    st.subheader("🌿 ESG Scores")
                    esg_df = pd.DataFrame.from_dict(esg_scores, orient="index", columns=["ESG Score"])
                    st.dataframe(esg_df)

                # Heatmap
                st.subheader("🔥 Risk Heatmap (Correlation Matrix)")
                corr_matrix = calculate_correlation_heatmap(data)
                heatmap_fig = px.imshow(
                    corr_matrix,
                    text_auto=True,
                    color_continuous_scale="RdBu_r",
                    title="Correlation between Stock Returns",
                    aspect="auto"
                )
                st.plotly_chart(heatmap_fig, use_container_width=True)

                # VaR & CVaR
                st.subheader("📉 Value at Risk (VaR) & Conditional VaR")
                returns = data.pct_change().dropna().dot(np.array(list(weights.values())))
                var_95 = np.percentile(returns, 5)
                cvar_95 = returns[returns <= var_95].mean()
                st.metric("VaR (95%)", f"{var_95*100:.2f}%")
                st.metric("CVaR (95%)", f"{cvar_95*100:.2f}%")

        except Exception as e:
            st.error(f"⚠️ An error occurred: {e}")
