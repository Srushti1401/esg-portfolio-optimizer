# optimizer.py
import yfinance as yf
import pandas as pd
import numpy as np
from pypfopt import expected_returns, risk_models, EfficientFrontier
import requests

FINNHUB_API_KEY = "d1ubn1pr01qp7ee2o6egd1ubn1pr01qp7ee2o6f0"

def fetch_esg_score(ticker):
    if not FINNHUB_API_KEY:
        return None
    try:
        url = f"https://finnhub.io/api/v1/stock/esg?symbol={ticker}&token={FINNHUB_API_KEY}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            return data.get("esgScore")
    except Exception:
        return None
    return None

def get_data(tickers, use_esg=False, min_score=0):
    df = yf.download(tickers, start="2023-01-01", progress=False, group_by='ticker', auto_adjust=True)
    if df.empty:
        raise ValueError("No price data found for the given tickers.")

    price_data = pd.DataFrame()
    for ticker in tickers:
        try:
            ticker_data = df[ticker] if isinstance(df.columns, pd.MultiIndex) else df
            price_data[ticker] = ticker_data["Adj Close"] if "Adj Close" in ticker_data else ticker_data["Close"]
        except KeyError:
            continue

    price_data.dropna(axis=1, inplace=True)

    esg_scores = {}
    if use_esg:
        valid_tickers = []
        for t in price_data.columns:
            score = fetch_esg_score(t)
            if score is None:
                score = np.random.randint(50, 100)
            esg_scores[t] = score
            if score >= min_score:
                valid_tickers.append(t)
        price_data = price_data[valid_tickers]
        esg_scores = {k: v for k, v in esg_scores.items() if k in valid_tickers}
    else:
        esg_scores = {t: np.random.randint(60, 95) for t in price_data.columns}

    return price_data, esg_scores

def optimize_portfolio(price_data):
    mu = expected_returns.mean_historical_return(price_data)
    S = risk_models.sample_cov(price_data)

    ef = EfficientFrontier(mu, S)
    weights = ef.max_sharpe()
    cleaned_weights = ef.clean_weights()
    perf = ef.portfolio_performance()

    return cleaned_weights, perf[0], perf[1], perf[2]

def calculate_correlation_heatmap(data):
    returns = data.pct_change().dropna()
    return returns.corr()
